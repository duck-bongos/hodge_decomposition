# TODO.md
Header Files
 * WedgeProduct.h
 	* double CWedgeOperator<M>::wedge_product()
 	* double CWedgeOperator<M>::wedge_star_product()

Source Files
  * HodgeDecomposition.cpp
    * CHodgeDecomposition::_d()
    * CHodgeDecomposition::_d()
    * CHodgeDecomposition::_delta()
    * CHodgeDecomposition::_delta()
    * CHodgeDecomposition::_remove_exact_form()
    * CHodgeDecomposition::_remove_exact_form()
    * CHodgeDecomposition::_compute_coexact_form()
    * CHodgeDecomposition::_remove_coexact_form()